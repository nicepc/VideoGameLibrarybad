﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace VideoGameLibrary.Migrations.Identity
{
    public partial class addUsername : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
